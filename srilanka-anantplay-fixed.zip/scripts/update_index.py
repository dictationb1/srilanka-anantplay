#!/usr/bin/env python3
"""
Sri Lanka AnantPlay Index — self-updating health checker & playlist generator.

Reads channels_master.json (the source of truth), optionally merges newly
discovered Sri Lankan (.lk) channels from the iptv-org API, health-checks every
candidate stream concurrently, then regenerates:
    srilanka_category.m3u, srilanka_language.m3u, srilanka_sites.json,
    index.json, sources.txt, README.md (status table), STATUS.md

Verdicts (so geo-routed CDN edges are never wrongly deleted):
    working     HTTP 200 + #EXTM3U/#EXT-X seen            -> keep in playlist
    blocked     HTTP 403 / other 4xx (geo or UA gate)     -> keep, flagged
    unreachable connection timeout / DNS / TLS failure    -> keep, flagged
                (GitHub runners sit in US/EU; many Sri Lankan CDN edges only
                 accept Asian connections — AnantPlay hides them on-device if
                 they really are down for the user)
    dead        HTTP 404 / 410 (the resource is gone)     -> drop from playlist

Run:  python3 scripts/update_index.py [--no-fetch] [--timeout 12]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime
import json
import os
import sys
import tempfile

import requests

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_BASE = "https://raw.githubusercontent.com/dictationb1/srilanka-anantplay/main"
IPTV_ORG_CHANNELS = "https://iptv-org.github.io/api/channels.json"
IPTV_ORG_STREAMS = "https://iptv-org.github.io/api/streams.json"

UA = ("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130 Mobile Safari/537.36")
LK_TZ = datetime.timezone(datetime.timedelta(hours=5, minutes=30))  # UTC+05:30

CATEGORY_ORDER = ["National", "News", "General", "Entertainment", "Tamil", "English",
                  "Sports", "Religious", "Education", "Kids", "Culture", "Visual Radio"]
LANG_ORDER = ["Sinhala", "Tamil", "English"]
# majors shown first in the sites.json "live" row
SITE_RANK = ["Rupavahini.lk", "TVDerana.lk", "AdaDerana24x7.lk", "SirasaTV.lk", "TV1.lk",
             "ITN.lk", "Swarnavahini.lk", "HiruTV.lk", "SiyathaTV.lk", "TNLTV.lk",
             "ChannelEye.lk", "NethraTV.lk", "VasanthamTV.lk", "ShakthiTV.lk", "NewsFirst.lk"]

FAIL = "\033[31m"; OK = "\033[32m"; WARN = "\033[33m"; DIM = "\033[2m"; END = "\033[0m"
def c(color: str, msg: str) -> str:
    return f"{color}{msg}{END}" if sys.stdout.isatty() else msg


# --------------------------------------------------------------------------- #
# Health checking
# --------------------------------------------------------------------------- #
def probe(url: str, timeout: float) -> dict:
    """Check one stream URL. Never raises; returns a verdict dict."""
    try:
        r = requests.get(url, headers={"User-Agent": UA}, timeout=timeout,
                         verify=False, allow_redirects=True, stream=True)
        code = r.status_code
        if code in (404, 410):
            return {"verdict": "dead", "http": code, "detail": "resource gone"}
        if code == 403:
            return {"verdict": "blocked", "http": code, "detail": "403 (geo/UA gated)"}
        if code >= 400:
            return {"verdict": "blocked", "http": code, "detail": f"HTTP {code}"}
        head = r.raw.read(2048, decode_content=True) if r.raw is not None else b""
        text = (head or b"").decode("utf-8", "replace")
        if "#EXTM3U" in text or "#EXT-X" in text:
            return {"verdict": "working", "http": code, "detail": "HLS manifest OK"}
        if text.lstrip().lower().startswith(("<!doctype", "<html")):
            return {"verdict": "dead", "http": code, "detail": "HTML page, not a stream"}
        # 200 with a non-HLS body (may be a proxy that needs the app's player): keep, flagged
        return {"verdict": "blocked", "http": code, "detail": "200 but not #EXTM3U"}
    except requests.exceptions.Timeout:
        return {"verdict": "unreachable", "http": 0, "detail": "timeout (geo-routed edge?)"}
    except requests.exceptions.ConnectionError as e:
        detail = str(getattr(e, "args", [e])[:1])[0][:80] if getattr(e, "args", None) else str(e)[:80]
        return {"verdict": "unreachable", "http": 0, "detail": f"conn: {detail}"}
    except Exception as e:  # noqa: BLE001
        return {"verdict": "unreachable", "http": 0, "detail": str(e)[:80]}


def check_all(candidates: list[tuple[str, dict]], timeout: float, workers: int = 16) -> dict:
    """candidates: [(channel_tvg_id, stream_dict), ...] -> {(tvg, url): verdict_dict}"""
    out = {}
    with cf.ThreadPoolExecutor(workers) as ex:
        futs = {ex.submit(probe, s["url"], timeout): (tvg, s) for tvg, s in candidates}
        done = 0
        for f in cf.as_completed(futs):
            tvg, s = futs[f]
            v = f.result()
            out[(tvg, s["url"])] = v
            done += 1
            icon = {"working": OK + "✓" + END, "dead": FAIL + "✗" + END,
                    "blocked": WARN + "⊘" + END, "unreachable": WARN + "?" + END}[v["verdict"]]
            if sys.stdout.isatty() or v["verdict"] != "working":
                print(f"  [{icon}] {tvg:28s} {v['verdict']:11s} {DIM}{v['detail'][:60]}{END}  {s['url'][:80]}")
            if done % 25 == 0:
                print(f"  … {done}/{len(candidates)} checked", flush=True)
    return out


# --------------------------------------------------------------------------- #
# iptv-org merge (optional discovery of new .lk channels)
# --------------------------------------------------------------------------- #
def merge_iptv_org(master: dict, timeout: float) -> int:
    """Add any iptv-org LK channel we do not know yet (streams + metadata)."""
    try:
        channels = requests.get(IPTV_ORG_CHANNELS, timeout=timeout, verify=False).json()
        streams = requests.get(IPTV_ORG_STREAMS, timeout=timeout, verify=False).json()
    except Exception as e:  # noqa: BLE001
        print(c(WARN, f"! iptv-org API unreachable ({e}); skipping merge"))
        return 0
    known = {ch["tvg_id"].lower() for ch in master["channels"]}
    by_channel: dict[str, list] = {}
    for s in streams:
        by_channel.setdefault(s.get("channel") or "", []).append(s)
    added = 0
    for ch in channels:
        cid = ch.get("id", "")
        if ch.get("country") != "LK" or cid.lower() in known or ch.get("is_nsfw"):
            continue
        ss = by_channel.get(cid, [])
        if not ss:
            continue
        master["channels"].append({
            "tvg_id": cid,
            "name": ch.get("name") or cid.replace(".lk", ""),
            "category": "General",
            "language": "Sinhala",
            "logo": ch.get("logo") or "",
            "streams": [{"url": s["url"], "quality": s.get("quality") or "SD",
                         "status": "candidate", "note": "discovered via iptv-org"} for s in ss],
            "site": ch.get("website") or "",
            "youtube": "",
            "mirrors": [],
        })
        added += 1
        print(c(OK, f"+ new iptv-org channel: {cid} ({len(ss)} streams)"))
    return added


# --------------------------------------------------------------------------- #
# Generators
# --------------------------------------------------------------------------- #
def stream_sort_key(s: dict):
    q = {"1080p": 0, "720p": 1, "576p": 2, "480p": 3, "360p": 4}
    live = 0 if s.get("_verdict") == "working" else 1
    return (live, q.get(s.get("quality", ""), 9))


def usable(s: dict) -> bool:
    # keep_even_if_dead: a CDN edge that only serves Asian networks 404s from the
    # US/EU GitHub runner but works in Sri Lanka (e.g. Channel Eye's tulix edge);
    # never drop those on the runner's word alone.
    if s.get("keep_even_if_dead"):
        return True
    return s.get("_verdict") in ("working", "blocked", "unreachable")


def m3u_for(channels: list[dict], group_of) -> tuple[str, int]:
    lines, n = ["#EXTM3U"], 0
    for group in (CATEGORY_ORDER if group_of == "category" else LANG_ORDER):
        for ch in channels:
            if group_of == "category":
                if ch["category"] != group:
                    continue
            elif ch["language"] != group:
                continue
            streams = sorted([s for s in ch.get("streams", []) if usable(s)], key=stream_sort_key)
            for i, s in enumerate(streams):
                label = ch["name"] if i == 0 else f"{ch['name']} (Mirror {i})"
                lines.append(
                    f'#EXTINF:-1 tvg-id="{ch["tvg_id"]}@SD" tvg-name="{ch["name"]}" '
                    f'tvg-logo="{ch.get("logo", "")}" group-title="{group}",{label}')
                lines.append(s["url"])
                n += 1
    return "\n".join(lines) + "\n", n


def site_rank_key(ch: dict):
    try:
        return (0, SITE_RANK.index(ch["tvg_id"]))
    except ValueError:
        return (1, 0)


def site_entry(ch: dict) -> dict:
    mirrors = [m for m in ch.get("mirrors", []) if m not in (ch.get("site"), ch.get("youtube"))]
    if ch.get("youtube") and ch["youtube"] != ch.get("site"):
        mirrors.insert(0, ch["youtube"])
    name = ch["name"] if ch["name"].endswith("Live") else ch["name"] + " Live"
    group = "Sri Lanka " + (ch["category"] if ch["category"] not in ("National", "General") else "TV")
    tags = [t for t in [ch["language"], ch["category"], "Official"] if t not in ("National", "General")]
    # dedupe while keeping order (Tamil language + Tamil category -> one "Tamil" tag)
    seen, uniq = set(), []
    for t in tags:
        if t not in seen:
            seen.add(t)
            uniq.append(t)
    return {"name": name, "url": ch["site"], "mirrors": mirrors[:3],
            "tags": uniq, "group": group, "pick": True, "index": False}


def build_sites(channels: list[dict]) -> dict:
    ordered = sorted(channels, key=site_rank_key)
    languages = {lang: [{"name": site_entry(ch)["name"], "url": ch["site"]}
                        for ch in ordered if ch["language"] == lang and ch.get("site")]
                 for lang in LANG_ORDER}
    return {"rows": {"live": [site_entry(ch) for ch in ordered if ch.get("site")]},
            "languages": languages}


def build_readme(master: dict, verdicts: dict) -> str:
    now = datetime.datetime.now(LK_TZ).strftime("%Y-%m-%d %H:%M Sri Lanka Time (UTC+05:30)")
    chans = master["channels"]

    def v_of(tvg: str, url: str) -> str:
        v = verdicts.get((tvg, url), {})
        return v.get("verdict", "unknown")

    working = [(t, u) for (t, u), v in verdicts.items() if v["verdict"] == "working"]
    direct_channels = {ch["tvg_id"] for ch in chans
                       if any(v_of(ch["tvg_id"], s["url"]) == "working" for s in ch.get("streams", []))}
    keep_channels = {ch["tvg_id"] for ch in chans
                     if any(v_of(ch["tvg_id"], s["url"]) in ("working", "blocked", "unreachable")
                            for s in ch.get("streams", []))}

    icon = {"working": "🟢", "blocked": "🟡", "unreachable": "🟡", "dead": "🔴", "unknown": "⚪",
            "none": "🔵"}
    rows = []
    for ch in sorted(chans, key=site_rank_key):
        ss = ch.get("streams", [])
        best = "none"
        for verdict in ["working", "blocked", "unreachable"]:
            if any(v_of(ch["tvg_id"], s["url"]) == verdict for s in ss):
                best = verdict
                break
        if ss and best == "none":
            best = "dead" if not any(s.get("keep_even_if_dead") for s in ss) else "unreachable"
        mode = ("Direct IPTV" if best == "working"
                else "Direct (in-region)" if any(s.get("keep_even_if_dead") for s in ss) or ch["tvg_id"] in keep_channels
                else "Official Site / YouTube" if ch.get("site") else "—")
        rows.append(f"| {icon[best]} | {ch['name']} | {ch['category']} | {ch['language']} | {mode} | "
                    f"{len(ss)} | {ch.get('site') or ch.get('youtube') or ''} |")
    table = "\n".join(rows)

    return f"""# 🇱🇰 Sri Lanka Complete TV Index for AnantPlay

> Self-updating index of every Sri Lankan TV channel & visual-radio station for the
> [AnantPlay](https://github.com/AnantPlay/android) app (Android / Android TV).
> **Last checked:** {now} · **Channels tracked:** {len(chans)} ·
> **Direct streams live right now:** {len(working)} (of {sum(len(c.get('streams', [])) for c in chans)} checked)

## 📥 Add to AnantPlay (English)

1. Open **AnantPlay → Settings → Sources → Add an index by link**
2. Paste: `{RAW_BASE}/index.json`
3. Both sources appear — tap **Add** on **each**:
   * **Sri Lanka IPTV (All Verified Channels)** → channels appear on the **IPTV tab** (grouped by category, with a 🇱🇰 Sri Lanka chip; the Languages button groups them by Sinhala / Tamil / English).
   * **Sri Lanka Official Live TV (All Channels Web Extractor)** → every broadcaster appears as a card on **Home → Live TV** row; opening one loads the official live page and AnantPlay sniffs the stream natively on your device (your own IP & headers — best for token-rotating players like Derana, Sirasa, Swarnavahini, Hiru, ITN).
4. AnantPlay re-downloads both lists automatically every **12 hours**.

## 📥 AnantPlay එකට එකතු කරන්න (සිංහල)

1. **AnantPlay → Settings → Sources → Add an index by link** අරින්න
2. මේ ලින්ක් එක paste කරන්න: `{RAW_BASE}/index.json`
3. පෙන්නන **source 2ම** **Add** කරන්න:
   * **Sri Lanka IPTV** → **IPTV tab** එකේ නාලිකා පෙනේ (කාණ්ඩ අනුව; Sinhala / Tamil / English භාෂා බොත්තමත් ඇත).
   * **Sri Lanka Official Live TV** → **Home → Live TV** පේළියේ සෑම නාලිකාවකම කාඩ්පතක් පෙනේ; එය විවෘත කළාම AnantPlay රාජ්‍ය නිල ලයිව් පිටුවෙන්ම ඔබේ දුරකථනයේදී stream එක ගනී (Derana, Sirasa, Swarnavahini, Hiru, ITN වගේ token මාරුවෙන players සඳහා හොඳම ක්‍රමය).
4. පැය **12කට** වරක් ලැයිස්තු ස්වයංක්‍රීයව යාවත්කාලීන වේ.

## 📺 Live Channel Status

🟢 direct HLS verified · 🟡 kept but geo-routed / gated from the check runner · 🔴 stream gone (site/YouTube extractor still works) · 🔵 no public direct HLS — official site / YouTube live page only

| | Channel | Category | Language | Best mode | Streams | Official page |
|---|---|---|---|---|---|---|
{table}

## 🔧 Troubleshooting

* **A channel does not start** — open it again (AnantPlay probes each stream and remembers failures), or use the **Home → Live TV** card for the same channel (on-device extraction).
* **Watching from outside Sri Lanka and a stream stalls** — some broadcaster CDNs allow Asian IPs only. Toggle **Settings → Cloudflare WARP** in AnantPlay (routes you through Cloudflare's network) and retry.
* **Everything empty after adding the index** — check the app refreshed the sources (Settings → Sources shows both lists; re-add or wait for the 12-hour refresh). GitHub raw must be reachable.
* **A channel disappeared** — GitHub Actions removed its dead link (HTTP 404/410) at the last sweep; the **Live TV** site card for it still works.

## 🤖 Self-updating automation

GitHub Actions (`.github/workflows/auto-update.yml`) runs `scripts/update_index.py` every **6 hours**:
health-checks every stream, drops confirmed-dead links (404/410), keeps geo-routed ones, merges new
Sri Lankan channels discovered by iptv-org, and re-commits all generated files with an
updated status table (timestamps in Sri Lanka Time). Manual run: **Actions → Auto-Update → Run workflow**.

## 📁 Repository layout

```
index.json               ← add THIS link in AnantPlay
srilanka_category.m3u    ← direct streams, grouped by category
srilanka_language.m3u    ← same streams, grouped by Sinhala/Tamil/English
srilanka_sites.json      ← official live pages for every channel (Home → Live TV)
channels_master.json     ← source-of-truth database (edit channels here)
sources.txt              ← legacy fallback format
scripts/update_index.py  ← health checker + generator (runs on GitHub Actions)
STATUS.md                ← per-stream check log (auto-generated)
```

## 📜 Licence & sources

Free-To-Air streams and official broadcaster pages only — no pay-TV feeds, no DRM.
Stream candidates are cross-checked against the public
[iptv-org](https://github.com/iptv-org/iptv) database. EPG fans: see the community
[Sri Lanka IPTV EPG (Dialog XMLTV)](https://github.com/KAWDHITHA-NIRMAL/Sri-Lanka-IPTV-EPG) project.
Maintained by [dictationb1](https://github.com/dictationb1).
"""


def build_status(master: dict, verdicts: dict) -> str:
    now = datetime.datetime.now(LK_TZ).strftime("%Y-%m-%d %H:%M:%S +05:30")
    lines = [f"# Stream status log", "", f"Auto-generated by `scripts/update_index.py` — {now}", "",
             "| Verdict | Meaning | Action |", "|---|---|---|",
             "| working | HTTP 200 + #EXTM3U | in playlists |",
             "| blocked | 403/4xx or non-HLS 200 | kept, flagged |",
             "| unreachable | timeout / connection refused | kept (geo-routed edge; runner is US/EU) |",
             "| dead | 404/410 or HTML page | dropped from playlists |", ""]
    for (tvg, url), v in sorted(verdicts.items()):
        lines.append(f"- `{tvg}` **{v['verdict']}** ({v['detail']}) `{url}`")
    counts = {}
    for v in verdicts.values():
        counts[v["verdict"]] = counts.get(v["verdict"], 0) + 1
    lines += ["", f"Totals: {json.dumps(counts, ensure_ascii=False)}", ""]
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-fetch", action="store_true", help="skip the iptv-org merge")
    ap.add_argument("--timeout", type=float, default=12.0)
    args = ap.parse_args()

    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    master_path = os.path.join(REPO, "channels_master.json")
    master = json.load(open(master_path, encoding="utf-8"))
    print(c(DIM, f"loaded {len(master['channels'])} channels from channels_master.json"))

    if not args.no_fetch:
        n = merge_iptv_org(master, args.timeout)
        print(c(OK if n else DIM, f"iptv-org merge: {n} new channel(s)"))

    # health-check every candidate stream in the master DB
    candidates = [(ch["tvg_id"], s) for ch in master["channels"] for s in ch.get("streams", [])
                  if s.get("url")]
    print(c(DIM, f"health-checking {len(candidates)} stream candidates…"))
    verdicts = check_all(candidates, args.timeout)

    # write verdicts back onto the stream dicts
    for ch in master["channels"]:
        for s in ch.get("streams", []):
            v = verdicts.get((ch["tvg_id"], s["url"]))
            if v:
                s["_verdict"] = v["verdict"]
                s["_detail"] = v["detail"]
                s["_checked"] = datetime.datetime.now(LK_TZ).strftime("%Y-%m-%d %H:%M")
                s["status"] = v["verdict"] if v["verdict"] != "unreachable" else "asia-routed"

    # ---- generate everything ----
    cat_m3u, cat_n = m3u_for(master["channels"], "category")
    lang_m3u, lang_n = m3u_for(master["channels"], "language")
    open(os.path.join(REPO, "srilanka_category.m3u"), "w", encoding="utf-8").write(cat_m3u)
    open(os.path.join(REPO, "srilanka_language.m3u"), "w", encoding="utf-8").write(lang_m3u)
    print(c(OK, f"srilanka_category.m3u ({cat_n} streams) · srilanka_language.m3u ({lang_n})"))

    sites = build_sites(master["channels"])
    json.dump(sites, open(os.path.join(REPO, "srilanka_sites.json"), "w", encoding="utf-8"),
              indent=2, ensure_ascii=False)
    print(c(OK, f"srilanka_sites.json ({len(sites['rows']['live'])} live cards)"))

    index = {
      "name": "Sri Lanka Complete TV Index",
      "sources": [
        {"id": "sl-iptv-all", "name": "Sri Lanka IPTV (All Verified Channels)",
         "description": "Verified direct Sri Lankan FTA IPTV streams by category, country (.lk) & language",
         "type": "playlist", "url": f"{RAW_BASE}/srilanka_category.m3u",
         "languages": f"{RAW_BASE}/srilanka_language.m3u", "adult": False, "default": True},
        {"id": "sl-official-live-sites", "name": "Sri Lanka Official Live TV (All Channels Web Extractor)",
         "description": "Official live pages for TV Derana, Ada Derana, Sirasa, Swarnavahini, Hiru, ITN, "
                        "Rupavahini & all SL channels via AnantPlay native player",
         "type": "sites", "url": f"{RAW_BASE}/srilanka_sites.json", "adult": False, "default": True},
      ],
    }
    json.dump(index, open(os.path.join(REPO, "index.json"), "w", encoding="utf-8"),
              indent=2, ensure_ascii=False)
    open(os.path.join(REPO, "sources.txt"), "w", encoding="utf-8").write(
        f"Sri Lanka IPTV (All Verified Channels)|{RAW_BASE}/srilanka_category.m3u\n"
        f"Sri Lanka Official Live TV Sites|{RAW_BASE}/srilanka_sites.json\n")
    print(c(OK, "index.json + sources.txt"))

    open(os.path.join(REPO, "README.md"), "w", encoding="utf-8").write(build_readme(master, verdicts))
    open(os.path.join(REPO, "STATUS.md"), "w", encoding="utf-8").write(build_status(master, verdicts))
    json.dump(master, open(master_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    print(c(OK, "README.md (status table) + STATUS.md + channels_master.json (statuses saved)"))

    counts = {}
    for v in verdicts.values():
        counts[v["verdict"]] = counts.get(v["verdict"], 0) + 1
    print(c(OK, f"DONE  working={counts.get('working', 0)}  blocked={counts.get('blocked', 0)}  "
                f"unreachable={counts.get('unreachable', 0)}  dead={counts.get('dead', 0)}"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
