# 🇱🇰 Sri Lanka Complete TV Index for AnantPlay

> Self-updating index of every Sri Lankan TV channel & visual-radio station for the
> [AnantPlay](https://github.com/AnantPlay/android) app (Android / Android TV).
> **Last checked:** 2026-11-20 19:48 Sri Lanka Time (UTC+05:30) · **Channels tracked:** 72 ·
> **Direct streams live right now:** 12 (of 23 checked)

## 📥 Add to AnantPlay (English)

1. Open **AnantPlay → Settings → Sources → Add an index by link**
2. Paste: `https://raw.githubusercontent.com/dictationb1/srilanka-anantplay/main/index.json`
3. Both sources appear — tap **Add** on **each**:
   * **Sri Lanka IPTV (All Verified Channels)** → channels appear on the **IPTV tab** (grouped by category, with a 🇱🇰 Sri Lanka chip; the Languages button groups them by Sinhala / Tamil / English).
   * **Sri Lanka Official Live TV (All Channels Web Extractor)** → every broadcaster appears as a card on **Home → Live TV** row; opening one loads the official live page and AnantPlay sniffs the stream natively on your device (your own IP & headers — best for token-rotating players like Derana, Sirasa, Swarnavahini, Hiru, ITN).
4. AnantPlay re-downloads both lists automatically every **12 hours**.

## 📥 AnantPlay එකට එකතු කරන්න (සිංහල)

1. **AnantPlay → Settings → Sources → Add an index by link** අරින්න
2. මේ ලින්ක් එක paste කරන්න: `https://raw.githubusercontent.com/dictationb1/srilanka-anantplay/main/index.json`
3. පෙන්නන **source 2ම** **Add** කරන්න:
   * **Sri Lanka IPTV** → **IPTV tab** එකේ නාලිකා පෙනේ (කාණ්ඩ අනුව; Sinhala / Tamil / English භාෂා බොත්තමත් ඇත).
   * **Sri Lanka Official Live TV** → **Home → Live TV** පේළියේ සෑම නාලිකාවකම කාඩ්පතක් පෙනේ; එය විවෘත කළාම AnantPlay රාජ්‍ය නිල ලයිව් පිටුවෙන්ම ඔබේ දුරකථනයේදී stream එක ගනී (Derana, Sirasa, Swarnavahini, Hiru, ITN වගේ token මාරුවෙන players සඳහා හොඳම ක්‍රමය).
4. පැය **12කට** වරක් ලැයිස්තු ස්වයංක්‍රීයව යාවත්කාලීන වේ.

## 📺 Live Channel Status

🟢 direct HLS verified · 🟡 kept but geo-routed / gated from the check runner · 🔴 stream gone (site/YouTube extractor still works) · 🔵 no public direct HLS — official site / YouTube live page only

| | Channel | Category | Language | Best mode | Streams | Official page |
|---|---|---|---|---|---|---|
| 🟢 | Rupavahini | National | Sinhala | Direct IPTV | 2 | https://tv.rupavahini.lk/rupavahini-live-webcast |
| 🔵 | TV Derana | General | Sinhala | Official Site / YouTube | 0 | https://www.derana.lk/live/index.php |
| 🔵 | Ada Derana 24x7 | News | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@AdaDerana_24/live |
| 🔵 | Sirasa TV | General | Sinhala | Official Site / YouTube | 0 | https://live.sirasatv.lk/ |
| 🔵 | TV 1 | News | Sinhala | Official Site / YouTube | 0 | https://tv1.lk/ |
| 🔵 | ITN | National | Sinhala | Official Site / YouTube | 0 | https://itn.lk/live/ |
| 🟡 | Swarnavahini | Entertainment | Sinhala | Direct (in-region) | 1 | https://swarnavahini.lk/ |
| 🟢 | Hiru TV | Entertainment | Sinhala | Direct IPTV | 1 | https://www.hirutv.lk/hirulive.php |
| 🟢 | Siyatha TV | Entertainment | Sinhala | Direct IPTV | 1 | https://siyathatv.lk/live/ |
| 🔵 | TNL TV | General | Sinhala | Official Site / YouTube | 0 | https://tnltv.lk/tv.html |
| 🟡 | Channel Eye | National | English | Direct (in-region) | 1 | https://channeleye.lk/rupavahini-live-webcast/ |
| 🔵 | Nethra TV | Tamil | Tamil | Official Site / YouTube | 0 | https://nethratv.lk/rupavahini-live-webcast/ |
| 🔵 | Vasantham TV | Tamil | Tamil | Official Site / YouTube | 0 | https://vasantham.lk/live/ |
| 🟢 | Shakthi TV | Tamil | Tamil | Direct IPTV | 1 | https://shakthitv.lk/live/ |
| 🔵 | Newsfirst | News | Sinhala | Official Site / YouTube | 0 | https://www.newsfirst.lk/live |
| 🔵 | Parliament TV | National | Sinhala | Official Site / YouTube | 0 | https://www.parliament.lk/en/parliament-live/chamber-live |
| 🔵 | Siyatha News | News | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@SiyathaNews/live |
| 🔵 | Hiru News | News | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/channel/UC5II-XiFOAMHfqIcdH3JOXQ |
| 🟢 | Athavan TV | Tamil | Tamil | Direct IPTV | 1 | https://athavantv.com/live/new-stream.php |
| 🔵 | DAN Tamil Oli | Tamil | Tamil | Official Site / YouTube | 0 | https://www.dantv.tv/index.php/73-dantv/live-tv/504-tamiloli |
| 🔵 | DAN News | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@DANNEWSTV/live |
| 🔵 | DAN Multi-Channel Live | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@DanChannelsLive |
| 🔵 | UTV Tamil | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@UTVHDLK/live |
| 🟡 | Star Tamil | Tamil | Tamil | Direct (in-region) | 1 | https://www.youtube.com/channel/UChDLy_EdNeFmw54sQqWVjfg/live |
| 🔵 | Varnam TV | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@varnamtv/live |
| 🔵 | IBC Tamil | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@IBCTamil/live |
| 🔵 | Guru TV | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@GuruTVLK/live |
| 🔵 | Yarl TV | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@YarlTV |
| 🔵 | Lankasri TV | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@LankasriTV/live |
| 🔵 | Capital TV | Tamil | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@CapitalTVOfficial/live |
| 🟡 | Shraddha TV | Religious | Sinhala | Direct (in-region) | 1 | https://www.shraddha.lk/ |
| 🟡 | The Buddhist TV | Religious | Sinhala | Direct (in-region) | 1 | https://www.thebuddhist.tv/ |
| 🔵 | Rangiri Sri Lanka TV | Religious | Sinhala | Official Site / YouTube | 0 | https://rangirisrilanka.lk/tv/ |
| 🟢 | Jaya TV | Religious | Sinhala | Direct IPTV | 1 | https://www.jayatv.lk/live |
| 🟢 | Verbum TV | Religious | Sinhala | Direct IPTV | 2 | https://www.verbumtv.com/ |
| 🔵 | Swarga TV | Religious | Tamil | Official Site / YouTube | 0 | https://www.youtube.com/@SwargaTV-Sri-Lanka/live |
| 🔵 | TV Didula | Religious | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@DidulaTV/live |
| 🔵 | Sarana TV | Religious | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@SaranaTV |
| 🔵 | Meth TV | Religious | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@MethTV |
| 🔵 | Heritage TV | Religious | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@HeritageTVLK |
| 🟡 | Charana TV | Education | Sinhala | Direct (in-region) | 1 | https://www.charanatv.lk/watch-live |
| 🔵 | Knowledge TV | Education | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@knowledgetv9248 |
| 🔵 | A Plus Kids TV | Kids | Sinhala | Official Site / YouTube | 0 | https://www.apluskidstvsl.com/ |
| 🔵 | Ridee TV | Education | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/channel/UCDR8ZWHRheX5Y1jn5ZS1Vag/live |
| 🔵 | AL Kuppiya TV | Education | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@ALkuppiya |
| 🔴 | Monara TV | Entertainment | Sinhala | Official Site / YouTube | 1 | https://www.youtube.com/@monaratvlk/live |
| 🔵 | Haritha TV | Entertainment | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@HarithaTVLIVE/live |
| 🔵 | Supreme TV | Entertainment | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@supremetvlive |
| 🟢 | Imai TV | Culture | Tamil | Direct IPTV | 2 | https://www.youtube.com/@ImaiTV |
| 🟡 | Asia TV | Entertainment | Sinhala | Direct (in-region) | 1 | https://www.asiatvnet.com/ |
| 🔴 | NDTV Lanka | Entertainment | Sinhala | Official Site / YouTube | 1 | https://www.youtube.com/@NDTVLanka |
| 🔵 | Gaja TV | Entertainment | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@GajaTVSriLanka |
| 🔵 | ThePapare TV | Sports | English | Official Site / YouTube | 0 | https://www.thepapare.com/live/ |
| 🟢 | Talent TV | Sports | Sinhala | Direct IPTV | 2 | https://talenttv.lk/ |
| 🔵 | Channel C | Entertainment | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@ChannelCSriLanka |
| 🔵 | Channel One (MBC) | English | English | Official Site / YouTube | 0 | https://www.youtube.com/@ChannelOneSriLanka |
| 🔵 | ART Television | English | English | Official Site / YouTube | 0 | https://www.youtube.com/@ARTTelevision |
| 🔵 | ETV | English | English | Official Site / YouTube | 0 | https://www.youtube.com/@ETVSriLanka |
| 🔵 | Colombo TV | Entertainment | Sinhala | Official Site / YouTube | 0 | https://www.colombotv.lk/ |
| 🔵 | Hiru FM (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@hirufm/live |
| 🔵 | Shaa FM (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@ShaaFM/live |
| 🔵 | Sirasa FM (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@SirasaFM/live |
| 🔵 | Derana FM (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@DeranaFM/live |
| 🔵 | Neth FM (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@NethFMradio |
| 🔵 | Siyatha FM (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@SiyathaFM/live |
| 🔵 | Y FM (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@yfmsrilanka/live |
| 🔵 | Yes FM (Visual Radio) | Visual Radio | English | Official Site / YouTube | 0 | https://www.youtube.com/@YesFMSriLanka |
| 🔵 | Gold FM (Visual Radio) | Visual Radio | English | Official Site / YouTube | 0 | https://www.youtube.com/@GoldFMSriLanka |
| 🔵 | Sun FM (Visual Radio) | Visual Radio | English | Official Site / YouTube | 0 | https://www.youtube.com/@SunFM |
| 🔵 | Lakhanda (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@LakhandaRadio |
| 🔵 | Rhythm World (Visual Radio) | Visual Radio | Sinhala | Official Site / YouTube | 0 | https://www.youtube.com/@rhythmworld |
| 🔴 | Ahasa TV | General | Sinhala | Official Site / YouTube | 1 | https://ahasatv.lk/ |

## 🔧 Troubleshooting

* **A channel does not start** — open it again (AnantPlay probes each stream and remembers failures), or use the **Home → Live TV** card for the same channel (on-device extraction).
* **Watching from outside Sri Lanka and a stream stalls** — some broadcaster CDNs allow Asian IPs only. Toggle **Settings → Cloudflare WARP** in AnantPlay (routes you through Cloudflare's network) and retry.
* **Everything empty after adding the index** — check the app refreshed the sources (Settings → Sources shows both lists; re-add or wait for the 12-hour refresh). GitHub raw must be reachable.
* **A channel disappeared** — GitHub Actions removed its dead link (HTTP 404/410) at the last sweep; the **Live TV** site card for it still works.

## 🤖 Self-updating automation

GitHub Actions (`.github/workflows/auto-update.yml`) runs `scripts/update_index.py` every **6 hours**:
health-checks every stream, drops confirmed-dead links (404/410), keeps geo-routed ones, merges new
Sri Lankan channels discovered by iptv-org, and re-commits all generated files with an
updated status table (timestamps in Sri Lanka Time). Manual run: **Actions → Auto-Update → Run workflow**.

## 📁 Repository layout

```
index.json               ← add THIS link in AnantPlay
srilanka_category.m3u    ← direct streams, grouped by category
srilanka_language.m3u    ← same streams, grouped by Sinhala/Tamil/English
srilanka_sites.json      ← official live pages for every channel (Home → Live TV)
channels_master.json     ← source-of-truth database (edit channels here)
sources.txt              ← legacy fallback format
scripts/update_index.py  ← health checker + generator (runs on GitHub Actions)
STATUS.md                ← per-stream check log (auto-generated)
```

## 📜 Licence & sources

Free-To-Air streams and official broadcaster pages only — no pay-TV feeds, no DRM.
Stream candidates are cross-checked against the public
[iptv-org](https://github.com/iptv-org/iptv) database. EPG fans: see the community
[Sri Lanka IPTV EPG (Dialog XMLTV)](https://github.com/KAWDHITHA-NIRMAL/Sri-Lanka-IPTV-EPG) project.
Maintained by [dictationb1](https://github.com/dictationb1).
